import pandas as pd
import numpy as np
import re
import matplotlib.pyplot as plt

import preprocessor as p
from gensim.parsing.preprocessing import remove_stopwords


from keras.preprocessing import text, sequence

from keras import utils
from keras.models import Sequential
from keras.layers import Dense, Activation, Dropout



###load files#####
map_text=pd.DataFrame(open("./hate/mapping.txt", encoding="utf8").read().splitlines())

train_text=pd.DataFrame(open("./hate/train_text.txt", encoding="utf8").read().splitlines())

train_labels=pd.DataFrame(open("./hate/train_labels.txt", encoding="utf8").read().splitlines())

test_text=pd.DataFrame(open("./hate/test_text.txt", encoding="utf8").read().splitlines())

test_labels=pd.DataFrame(open("./hate/test_labels.txt", encoding="utf8").read().splitlines())

val_text=pd.DataFrame(open("./hate/val_text.txt", encoding="utf8").read().splitlines())

val_labels=pd.DataFrame(open("./hate/val_labels.txt", encoding="utf8").read().splitlines())


print("train text: ",train_text.shape)
print("train label: ",train_labels.shape)
print("test text: ",test_text.shape)
print("label_number: ",map_text.shape[0])

print(train_text[0][0])
print(train_text[0][1])
print(train_text[0][2])
print(train_text[0][3])
print(train_text[0][4])
print(train_labels.head())
print(map_text)

############text preprocessing####################

X_train = []
for sen in train_text[0][:]:
    
    
    REPLACE_BY_SPACE_RE = re.compile('[/(){}\[\]\|@,;]')
    BAD_SYMBOLS_RE = re.compile('[^0-9a-z #+_]')

    sen = sen.lower() # lowercase text
    sen = REPLACE_BY_SPACE_RE.sub(' ', sen) # replace REPLACE_BY_SPACE_RE symbols by space in text. substitute the matched string in REPLACE_BY_SPACE_RE with space.
    sen = BAD_SYMBOLS_RE.sub('', sen) # remove symbols which are in BAD_SYMBOLS_RE from text. substitute the matched string in BAD_SYMBOLS_RE with nothing. 
    
    # Remove punctuations and numbers
    sentence = re.sub('[^a-zA-Z]', ' ', sen)

    # Single character removal
    sentence = re.sub(r"\s+[a-zA-Z]\s+", ' ', sentence)

    # Removing multiple spaces
    sentence = re.sub(r'\s+', ' ', sentence)
    #remove stop words
    sen = remove_stopwords(sen)
    
    
    X_train.append(sen)
    
X_test = []
for sen in test_text[0][:]:
    
    REPLACE_BY_SPACE_RE = re.compile('[/(){}\[\]\|@,;]')
    BAD_SYMBOLS_RE = re.compile('[^0-9a-z #+_]')

    sen = sen.lower() # lowercase text
    sen = REPLACE_BY_SPACE_RE.sub(' ', sen) # replace REPLACE_BY_SPACE_RE symbols by space in text. substitute the matched string in REPLACE_BY_SPACE_RE with space.
    sen = BAD_SYMBOLS_RE.sub('', sen) # remove symbols which are in BAD_SYMBOLS_RE from text. substitute the matched string in BAD_SYMBOLS_RE with nothing. 
    
    # Remove punctuations and numbers
    sentence = re.sub('[^a-zA-Z]', ' ', sen)

    # Single character removal
    sentence = re.sub(r"\s+[a-zA-Z]\s+", ' ', sentence)

    # Removing multiple spaces
    sentence = re.sub(r'\s+', ' ', sentence)
    #remove stop words
    sen = remove_stopwords(sen)
    
    
    X_test.append(sen)
y_train=train_labels[0]
y_test=test_labels[0]

print(X_train.head())

#####tokenization############
max_words = 1000

tokenize = text.Tokenizer(num_words=max_words, char_level=False)
tokenize.fit_on_texts(X_train) # only fit on train

x_train = tokenize.texts_to_matrix(X_train)
x_test = tokenize.texts_to_matrix(X_test)
print(x_train)

#########model creation#####
num_classes = map_text.shape[0]
y_train = utils.to_categorical(y_train, num_classes)
y_test = utils.to_categorical(y_test, num_classes)


batch_size = 10
epochs = 5

# Build the model
model = Sequential()
model.add(Dense(512, input_shape=(max_words,)))
model.add(Activation('relu'))
model.add(Dropout(0.05))
model.add(Dense(num_classes))
model.add(Activation('sigmoid'))

model.compile(loss='categorical_crossentropy',
              optimizer='adam',
              metrics=['accuracy'])
              
history = model.fit(x_train, y_train,
                    batch_size=batch_size,
                    epochs=epochs,
                    verbose=1,
                    validation_split=0.2)

#predict test text
ynew = model.predict_classes(x_test)
print(ynew)
np.savetxt("offensive.txt", ynew, fmt="%s")


###########Plot graphs
print(history.history)
plt.title('Accuracy')
plt.plot(history.history['accuracy'], label='train')
plt.plot(history.history['val_accuracy'], label='test')
plt.legend()
plt.savefig('hate1.png', bbox_inches='tight')
plt.show();

plt.title('Accuracy')
plt.plot(history.history['loss'], label='train')
plt.plot(history.history['val_loss'], label='test')
plt.legend()
plt.savefig('hate_loss1.png', bbox_inches='tight')
plt.show();